#made by kadyn

print("please enter the api key for your server")
api = input()
print (api)
Prompt = input("is this the correct api key for your server")
if Prompt in ['y', 'yes']:
    print("now run the server program to connect the tool")

else:
    while True:
        print("please close and reopen the program") 
